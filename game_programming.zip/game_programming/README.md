# game_programming_spring_2023
game_programming_spring_2023

Bu derste Unity ile 3D oyun tasarımı ve programlama bilgisi verilecektir.<br>
Dersi seçebilmek için Nesne Yönelimli Programcılık dersinden geçmiş olmanız gereklidir. (Görsel Programlama değil, Nesne Yönelimli Programlama dersinden geçme şartı!)<br>
*** Not kaygısı olmayan, haftalık ödev/sunum/araştırma yapacak, dönem sonuna kadar proje geliştirebilecek, son derece ağır şartlarda, zorlanarak kendisine bir şeyler katmak isteyen YÜKSEK MOTİVASYONLU, kendini öğrenmeye adamaktan kaçınmayan,algıları açık ve meraklı öğrencilerin dersi seçmesi iyi olacaktır.<br> 
Derste kullanılacak Unity Programı için ideal konfigurasyon: Intel i5/i7 (ryzen5/ryzen7) işlemci, 16 gb ram, tercihen harici ekran kartı. (Daha düşük konfigürasyonlarda programın çalışmama yada hata verme olasılığı mevcuttur!)<br>

Derste haftalık ödevler ve proje verilecektir.<br>
Haftalık ödevler verildiği hafta yapılmalıdır. Teslim Tarihi geçen ödevin telafisi olmayacaktır.<br>
Projeler Final haftasından önceki hafta ders saatinde kontrol edilecektir.(Dersi alttan alanlar sınav haftasında laptopları ile gelip göstereceklerdir.) Proje teslim etmeyen öğrenciler dersten kalırlar. Proje teslimini büte bırakan öğrenciler büt haftasında sınavdan sonra laptopları ile projelerini göstereceklerdir. Tüm öğrencilerin ilk 4 hafta içerisinde projelerini belirlemesi gerekmektedir. Projelerde 3D oyun geliştirilecektir! 2D ve Platform oyunları proje olarak alınamaz!<br>
Devamsızlık hakkı 4 haftadır. (Devamsızlıklar her hafta düzenli olarak OBS sistemine işleneceğinden geriye dönük hiç bir mazeret kabul edilmeyecektir.)<br>

Derste Unity Güncel sürüm kullanılacaktır. <br>
Kodlama için C# kullanılacaktır, bunun içinde Visual Studio Community Edition 2019 veya 2022 sürümlerinin kurulmuş olması gerekmektedir<br>

Vize : 100 puanlık test sınavı<br>
Final (Bütünleme) : 25 Puanlık sınav + 25 puan haftalık ödevler + 50 puan proje<br>

--- Müfredat Ana Başlıklar ---<br>
-Unity geliştirme ortamının kurulması<br>
-Workspace, assets, rigidbody, material<br>
-Keyboard control, destroy gameobject<br>
-Continuous motion, runtime processes<br>
-Vectors, force, collision<br>
-Character assets, camera control<br>
-Using Mixamo for characters animations<br>
-Voice and text<br>
-Menu<br>
-Car controller<br>
-Flight Simulator<br>
-Building project for cross platforms<br>
*** Müfredat öğrencinin hazırbulunuşluğuna, reaksiyonuna ve ritmine göre değişebilir
